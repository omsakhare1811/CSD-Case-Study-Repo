package com.pojo;

import java.sql.Date;

public class Rental {
	private int rentalId;
    private int movieId;
    private int customerId;
    private Date rentalStartDate;
    private Date rentalEndDate;
    private double totalCharge;
	public Rental() {
		super();
	}
	public Rental(int rentalId, int movieId, int customerId, Date rentalStartDate, Date rentalEndDate,
			double totalCharge) {
		super();
		this.rentalId = rentalId;
		this.movieId = movieId;
		this.customerId = customerId;
		this.rentalStartDate = rentalStartDate;
		this.rentalEndDate = rentalEndDate;
		this.totalCharge = totalCharge;
	}
	public int getRentalId() {
		return rentalId;
	}
	public void setRentalId(int rentalId) {
		this.rentalId = rentalId;
	}
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public Date getRentalStartDate() {
		return rentalStartDate;
	}
	public void setRentalStartDate(Date rentalStartDate) {
		this.rentalStartDate = rentalStartDate;
	}
	public Date getRentalEndDate() {
		return rentalEndDate;
	}
	public void setRentalEndDate(Date rentalEndDate) {
		this.rentalEndDate = rentalEndDate;
	}
	public double getTotalCharge() {
		return totalCharge;
	}
	public void setTotalCharge(double totalCharge) {
		this.totalCharge = totalCharge;
	}
	@Override
	public String toString() {
		return "rental [rentalId=" + rentalId + ", movieId=" + movieId + ", customerId=" + customerId
				+ ", rentalStartDate=" + rentalStartDate + ", rentalEndDate=" + rentalEndDate + ", totalCharge="
				+ totalCharge + "]";
	}
    
    
}
