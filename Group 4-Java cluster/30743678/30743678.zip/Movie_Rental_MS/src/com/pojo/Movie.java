package com.pojo;

public class Movie {
	private int movieId;
    private String title;
    private String genre;
    private int releaseYear;
    private double rentalPrice;
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public int getReleaseYear() {
		return releaseYear;
	}
	public void setReleaseYear(int releaseYear) {
		this.releaseYear = releaseYear;
	}
	public double getRentalPrice() {
		return rentalPrice;
	}
	public void setRentalPrice(double rentalPrice) {
		this.rentalPrice = rentalPrice;
	}
	public Movie() {
		super();
	}
	
	public Movie(int movieId, String title, String genre, int releaseYear, double rentalPrice) {
		super();
		this.movieId = movieId;
		this.title = title;
		this.genre = genre;
		this.releaseYear = releaseYear;
		this.rentalPrice = rentalPrice;
	}
	
	@Override
	public String toString() {
		return "movie [movieId=" + movieId + ", title=" + title + ", genre=" + genre + ", releaseYear=" + releaseYear
				+ ", rentalPrice=" + rentalPrice + "]";
	}
    
    
	
	

}
