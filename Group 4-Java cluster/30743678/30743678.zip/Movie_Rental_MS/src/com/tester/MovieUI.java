package com.tester;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.dao.CustomerDAO;
import com.dao.MovieDAO;
import com.dao.RentalDAO;
import com.exceptions.CustomerNotFoundException;
import com.exceptions.MovieNotFoundException;
import com.exceptions.RentalNotFoundException;
import com.pojo.Customer;
import com.pojo.Movie;
import com.pojo.Rental;

public class MovieUI {
    private static Scanner scanner = new Scanner(System.in);
    private static MovieDAO movieDAO = new MovieDAO();
    private static CustomerDAO customerDAO = new CustomerDAO();
    private static RentalDAO rentalDAO = new RentalDAO();

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n=== Movie Rental Management System ===");
            System.out.println("1. Manage Movies");
            System.out.println("2. Manage Customers");
            System.out.println("3. Manage Rentals");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    manageMovies();
                    break;
                case 2:
                    manageCustomers();
                    break;
                case 3:
                    manageRentals();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }


    //FROM HERE MANAGE MOVIE CHOICE IS IMPLEMENTED


    private static void manageMovies() {
        System.out.println("\n=== Manage Movies ===");
        System.out.println("1. Add a new movie");
        System.out.println("2. View movie details");
        System.out.println("3. Update movie information");
        System.out.println("4. Delete a movie");
        System.out.println("5. View all movies");
        System.out.println("6. Back to main menu");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        try {
            switch (choice) {
                case 1:
                    addMovie();
                    break;
                case 2:
                    viewMovie();
                    break;
                case 3:
                    updateMovie();
                    break;
                case 4:
                    deleteMovie();
                    break;
                case 5:
                    viewAllMovies();
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } catch (SQLException |MovieNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void addMovie() throws SQLException {
        System.out.print("Enter movie title: ");
        String title = scanner.nextLine();
        System.out.print("Enter movie genre: ");
        String genre = scanner.nextLine();
        System.out.print("Enter release year: ");
        int releaseYear = scanner.nextInt();
        System.out.print("Enter rental price: ");
        double rentalPrice = scanner.nextDouble();

        Movie movie = new Movie();
        movie.setTitle(title);
        movie.setGenre(genre);
        movie.setReleaseYear(releaseYear);
        movie.setRentalPrice(rentalPrice);

        movieDAO.addMovie(movie);
        System.out.println("Movie added successfully.");
    }

    private static void viewMovie() throws SQLException,MovieNotFoundException {
        System.out.print("Enter movie ID: ");
        int movieId = scanner.nextInt();
        Movie movie = movieDAO.getMovieById(movieId);
        if (movie != null) {
            System.out.println("Movie ID: " + movie.getMovieId());
            System.out.println("Title: " + movie.getTitle());
            System.out.println("Genre: " + movie.getGenre());
            System.out.println("Release Year: " + movie.getReleaseYear());
            System.out.println("Rental Price: " + movie.getRentalPrice());
        } else {
//            System.out.println("Movie not found.");
            throw new MovieNotFoundException("Movie with ID " + movieId + " not found.");
        }
    }

    private static void updateMovie() throws SQLException,MovieNotFoundException {
        System.out.print("Enter movie ID to update: ");
        int movieId = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        Movie movie = movieDAO.getMovieById(movieId);
        if (movie != null) {
            System.out.print("Enter new title (leave blank to keep current): ");
            String title = scanner.nextLine();
            if (!title.isEmpty()) {
                movie.setTitle(title);
            }
            System.out.print("Enter new genre (leave blank to keep current): ");
            String genre = scanner.nextLine();
            if (!genre.isEmpty()) {
                movie.setGenre(genre);
            }
            System.out.print("Enter new release year (0 to keep current): ");
            int releaseYear = scanner.nextInt();
            if (releaseYear != 0) {
                movie.setReleaseYear(releaseYear);
            }
            System.out.print("Enter new rental price (0 to keep current): ");
            double rentalPrice = scanner.nextDouble();
            if (rentalPrice != 0) {
                movie.setRentalPrice(rentalPrice);
            }

            movieDAO.updateMovie(movie);
            System.out.println("Movie updated successfully.");
        } else {
            throw new MovieNotFoundException("Movie with ID " + movieId + " not found.");
        }
    }

    private static void deleteMovie() throws SQLException {
        System.out.print("Enter movie ID to delete: ");
        int movieId = scanner.nextInt();
        movieDAO.deleteMovie(movieId);
        System.out.println("Movie deleted successfully.");
    }

    private static void viewAllMovies() throws SQLException {
        List<Movie> movies = movieDAO.getAllMovies();
        for (Movie movie : movies) {
            System.out.println(movie.getMovieId() + ": " + movie.getTitle() + " (" + movie.getReleaseYear() + ")");
        }
    }


    //FROM HERE MANAGE CUSTOMER CHOICE IS IMPLEMENTED

    private static void manageCustomers() {
        System.out.println("\n=== Manage Customers ===");
        System.out.println("1. Register a new customer");
        System.out.println("2. View customer details");
        System.out.println("3. Update customer information");
        System.out.println("4. Delete a customer");
        System.out.println("5. View all customers");
        System.out.println("6. Back to main menu");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        try {
            switch (choice) {
                case 1:
                    addCustomer();
                    break;
                case 2:
                    viewCustomer();
                    break;
                case 3:
                    updateCustomer();
                    break;
                case 4:
                    deleteCustomer();
                    break;
                case 5:
                    viewAllCustomers();
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } catch (SQLException | CustomerNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void addCustomer() throws SQLException {
        System.out.print("Enter customer name: ");
        String name = scanner.nextLine();
        System.out.print("Enter customer email: ");
        String email = scanner.nextLine();
        System.out.print("Enter customer phone number: ");
        String phoneNumber = scanner.nextLine();
        System.out.print("Enter customer address: ");
        String address = scanner.nextLine();

        Customer customer = new Customer();
        customer.setName(name);
        customer.setEmail(email);
        customer.setPhoneNumber(phoneNumber);
        customer.setAddress(address);

        customerDAO.addCustomer(customer);
        System.out.println("Customer registered successfully.");
    }

    private static void viewCustomer() throws SQLException,CustomerNotFoundException {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        Customer customer = customerDAO.getCustomerById(customerId);
        if (customer != null) {
            System.out.println("Customer ID: " + customer.getCustomerId());
            System.out.println("Name: " + customer.getName());
            System.out.println("Email: " + customer.getEmail());
            System.out.println("Phone Number: " + customer.getPhoneNumber());
            System.out.println("Address: " + customer.getAddress());
        } else {
//            System.out.println("Customer not found.");
            throw new CustomerNotFoundException("Customer with ID " + customerId + " not found.");

        }
    }

    private static void updateCustomer() throws SQLException,CustomerNotFoundException {
        System.out.print("Enter customer ID to update: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        Customer customer = customerDAO.getCustomerById(customerId);
        if (customer != null) {
            System.out.print("Enter new name (leave blank to keep current): ");
            String name = scanner.nextLine();
            if (!name.isEmpty()) {
                customer.setName(name);
            }
            System.out.print("Enter new email (leave blank to keep current): ");
            String email = scanner.nextLine();
            if (!email.isEmpty()) {
                customer.setEmail(email);
            }
            System.out.print("Enter new phone number (leave blank to keep current): ");
            String phoneNumber = scanner.nextLine();
            if (!phoneNumber.isEmpty()) {
                customer.setPhoneNumber(phoneNumber);
            }
            System.out.print("Enter new address (leave blank to keep current): ");
            String address = scanner.nextLine();
            if (!address.isEmpty()) {
                customer.setAddress(address);
            }

            customerDAO.updateCustomer(customer);
            System.out.println("Customer updated successfully.");
        } else {
            throw new CustomerNotFoundException("Customer with ID " + customerId + " not found.");

        }
    }

    private static void deleteCustomer() throws SQLException {
        System.out.print("Enter customer ID to delete: ");
        int customerId = scanner.nextInt();
        customerDAO.deleteCustomer(customerId);
        System.out.println("Customer deleted successfully.");
    }

    private static void viewAllCustomers() throws SQLException {
        List<Customer> customers = customerDAO.getAllCustomers();
        for (Customer customer : customers) {
            System.out.println(customer.getCustomerId() + ": " + customer.getName() + " (" + customer.getEmail() + ")");
        }
    }

    private static void manageRentals() {
        System.out.println("\n=== Manage Rentals ===");
        System.out.println("1. Rent a movie to a customer");
        System.out.println("2. Return a rented movie");
        System.out.println("3. View rental details");
        System.out.println("4. Back to main menu");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        try {
            switch (choice) {
                case 1:
                    rentMovie();
                    break;
                case 2:
                    returnMovie();
                    break;
                case 3:
                    viewRentalDetails();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } catch (SQLException |RentalNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void rentMovie() throws SQLException {
        System.out.print("Enter movie ID to rent: ");
        int movieId = scanner.nextInt();
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        System.out.print("Enter rental start date (YYYY-MM-DD): ");
        Date rentalStartDate = Date.valueOf(scanner.next());
        System.out.print("Enter rental end date (YYYY-MM-DD): ");
        Date rentalEndDate = Date.valueOf(scanner.next());

        Movie movie = movieDAO.getMovieById(movieId);
        if (movie == null) {
            System.out.println("Movie not found.");
            return;
        }

        Customer customer = customerDAO.getCustomerById(customerId);
        if (customer == null) {
            System.out.println("Customer not found.");
            return;
        }

        long duration = rentalEndDate.getTime() - rentalStartDate.getTime();
        int days = (int) (duration / (1000 * 60 * 60 * 24));
        double totalCharge = movie.getRentalPrice() * days;

        Rental rental = new Rental();
        rental.setMovieId(movieId);
        rental.setCustomerId(customerId);
        rental.setRentalStartDate(rentalStartDate);
        rental.setRentalEndDate(rentalEndDate);
        rental.setTotalCharge(totalCharge);

        rentalDAO.rentMovie(rental);
        System.out.println("Movie rented successfully. Total charge: $" + totalCharge);
    }

    private static void returnMovie() throws SQLException {
        System.out.print("Enter rental ID to return: ");
        int rentalId = scanner.nextInt();
        System.out.print("Enter rental end date (YYYY-MM-DD): ");
        Date rentalEndDate = Date.valueOf(scanner.next());
        rentalDAO.returnMovie(rentalId,rentalEndDate);
        System.out.println("Movie returned successfully.");
    }

    private static void viewRentalDetails() throws SQLException,RentalNotFoundException{
        System.out.print("Enter rental ID: ");
        int rentalId = scanner.nextInt();
        Rental rental = rentalDAO.getRentalById(rentalId);
        if (rental != null) {
            System.out.println("Rental ID: " + rental.getRentalId());
            System.out.println("Movie ID: " + rental.getMovieId());
            System.out.println("Customer ID: " + rental.getCustomerId());
            System.out.println("Rental Start Date: " + rental.getRentalStartDate());
            System.out.println("Rental End Date: " + rental.getRentalEndDate());
            System.out.println("Total Charge: $" + rental.getTotalCharge());
            return;
        }

//    	System.out.println("Rental details not found");
        throw new RentalNotFoundException("Rental with ID " + rentalId + " not found.");


    }



}