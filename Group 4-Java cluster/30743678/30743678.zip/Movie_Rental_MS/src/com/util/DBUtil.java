package com.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	public static Connection getDBConnection(){
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("driver loaded...");
			
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/MovieRentalDB","root","mysql@123");
		System.out.println("Connection established...");
		
		return con


				;
		}
		catch(ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

}