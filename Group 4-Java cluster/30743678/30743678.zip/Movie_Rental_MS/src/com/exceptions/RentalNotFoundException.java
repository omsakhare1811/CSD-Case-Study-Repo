package com.exceptions;

public class RentalNotFoundException extends Exception {
    public RentalNotFoundException(String message) {
        super(message);
    }
}