package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.pojo.Customer;
import com.util.DBUtil;

public class CustomerDAO {
	
	Connection con;
	
    public CustomerDAO() {
		System.out.println("inside customer dao layer....");
		con=DBUtil.getDBConnection();
	}
    
    public  void addCustomer(Customer customer) throws SQLException {
        String query = "INSERT INTO Customer (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
        try { 
             PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, customer.getName());
            stmt.setString(2, customer.getEmail());
            stmt.setString(3, customer.getPhoneNumber());
            stmt.setString(4, customer.getAddress());
            stmt.executeUpdate();
        }
        catch (Exception ex) {
			ex.printStackTrace();
		}
    }

    public  Customer getCustomerById(int customerId) throws SQLException {
        String query = "SELECT * FROM Customer WHERE customer_id = ?";
        try {
             PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, customerId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Customer(rs.getInt("customer_id"), rs.getString("name"), 
                                 rs.getString("email"), rs.getString("phone_number"), 
                                 rs.getString("address"));
            }
        }
        catch (Exception ex) {
			ex.printStackTrace();
		}
        return null;
    }

    public void updateCustomer(Customer customer) throws SQLException {
        String query = "UPDATE Customer SET name = ?, email = ?, phone_number = ?, address = ? WHERE customer_id = ?";
        try {
             PreparedStatement stmt = con.prepareStatement(query) ;
            stmt.setString(1, customer.getName());
            stmt.setString(2, customer.getEmail());
            stmt.setString(3, customer.getPhoneNumber());
            stmt.setString(4, customer.getAddress());
            stmt.setInt(5, customer.getCustomerId());
            stmt.executeUpdate();
        }
        catch (Exception ex) {
			ex.printStackTrace();
		}
    }

    public void deleteCustomer(int customerId) throws SQLException {
        String query = "DELETE FROM Customer WHERE customer_id = ?";
        try {
             PreparedStatement stmt = con.prepareStatement(query) ;
            stmt.setInt(1, customerId);
            stmt.executeUpdate();
        }
        catch (Exception ex) {
			ex.printStackTrace();
		}
    }
    
    public List<Customer> getAllCustomers() throws SQLException {
    	String query = "SELECT * FROM Customer";
    	List<Customer> customers = new ArrayList<>();
    	
    	try {
    		PreparedStatement stmt = con.prepareStatement(query);
              ResultSet rs = stmt.executeQuery();
              while (rs.next()) {
                  customers.add(new Customer(rs.getInt("customer_id"), rs.getString("name"), 
                                   rs.getString("email"), rs.getString("phone_number"), 
                                   rs.getString("address")));
    		}
    	}
        catch (Exception ex) {
			ex.printStackTrace();
		}
    	
    	return customers;
    }
    
}
