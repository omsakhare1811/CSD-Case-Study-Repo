package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.pojo.Movie;
import com.util.DBUtil;

public class MovieDAO {
	Connection con;
	
    public MovieDAO() {
		System.out.println("inside movie dao layer....");
		con=DBUtil.getDBConnection();
	}

	public void addMovie(Movie movie) throws SQLException {
        String query = "INSERT INTO Movie (title, genre, release_year, rental_price) VALUES (?, ?, ?, ?)";
        try {
        	PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, movie.getTitle());
            stmt.setString(2, movie.getGenre());
            stmt.setInt(3, movie.getReleaseYear());
            stmt.setDouble(4, movie.getRentalPrice());
            stmt.executeUpdate();
        }
        catch (Exception ex) {
			ex.printStackTrace();
		}
        
    }

    public Movie getMovieById(int movieId) throws SQLException {
        String query = "SELECT * FROM Movie WHERE movie_id = ?";
        try  {
        	PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, movieId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Movie(rs.getInt("movie_id"), rs.getString("title"), 
                                 rs.getString("genre"), rs.getInt("release_year"), 
                                 rs.getDouble("rental_price"));
            }
        }
        catch (Exception ex) {
			ex.printStackTrace();
		}
        return null;
    }

    public void updateMovie(Movie movie) throws SQLException {
        String query = "UPDATE Movie SET title = ?, genre = ?, release_year = ?, rental_price = ? WHERE movie_id = ?";
        try {
        	
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, movie.getTitle());
            stmt.setString(2, movie.getGenre());
            stmt.setInt(3, movie.getReleaseYear());
            stmt.setDouble(4, movie.getRentalPrice());
            stmt.setInt(5, movie.getMovieId());
            stmt.executeUpdate();
        }
        catch (Exception ex) {
			ex.printStackTrace();
		}
    }

    public void deleteMovie(int movieId) throws SQLException {
        String query = "DELETE FROM Movie WHERE movie_id = ?";
        try  {
            PreparedStatement stmt = con.prepareStatement(query) ;
            stmt.setInt(1, movieId);
            stmt.executeUpdate();
        }
        catch (Exception ex) {
			ex.printStackTrace();
        }
    }
    
    
    public List<Movie> getAllMovies() throws SQLException{
    	String query = "SELECT * FROM Movie";
    	List<Movie> movies = new ArrayList<>();
    	
    	try {
    		PreparedStatement stmt = con.prepareStatement(query);
    		ResultSet rs = stmt.executeQuery();
          while (rs.next()) {
              movies.add(new Movie(rs.getInt("movie_id"), rs.getString("title"), 
                               rs.getString("genre"), rs.getInt("release_year"), 
                               rs.getDouble("rental_price")));
          }
    	}
    	catch(Exception ex) {
    		ex.printStackTrace();
    	}
    	return movies;
    }
    

}