package com.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.pojo.Movie;
import com.pojo.Rental;
import com.util.DBUtil;

public class RentalDAO {
	Connection con;
	
    public RentalDAO() {
		System.out.println("inside customer dao layer....");
		con=DBUtil.getDBConnection();
	}

    // Method to rent a movie to a customer
    public void rentMovie(Rental rental) throws SQLException {
    	
    	
        String query = "INSERT INTO Rental (movie_id, customer_id, rental_start_date, rental_end_date, total_charge) VALUES (?, ?, ?, ?, ?)";
        try {
             PreparedStatement stmt = con.prepareStatement(query);

            stmt.setInt(1, rental.getMovieId());
            stmt.setInt(2, rental.getCustomerId());
            stmt.setDate(3, rental.getRentalStartDate());
            stmt.setDate(4, rental.getRentalEndDate());
            stmt.setDouble(5, rental.getTotalCharge());
            stmt.executeUpdate();
        }
        catch (Exception ex) {
			ex.printStackTrace();
		}
    }

    // Method to return a rented movie and update the total charge
    public void returnMovie(int rentalId, Date rentalEndDate) throws SQLException {
        String query = "UPDATE Rental SET rental_end_date = ?, total_charge = ? WHERE rental_id = ?";
        try {
             PreparedStatement stmt = con.prepareStatement(query);

            // Calculate total charge based on the rental price and rental duration
            Rental rental = getRentalById(rentalId);
            if (rental != null) {
                long duration = rentalEndDate.getTime() - rental.getRentalStartDate().getTime();
                long days = duration / (1000 * 60 * 60 * 24);
                double totalCharge = days * rental.getTotalCharge();

                stmt.setDate(1, rentalEndDate);
                stmt.setDouble(2, totalCharge);
                stmt.setInt(3, rentalId);
                stmt.executeUpdate();
            }
        }
        catch (Exception ex) {
			ex.printStackTrace();
		}
    }

    // Method to get rental details by rental ID
    public Rental getRentalById(int rentalId) throws SQLException {
        String query = "SELECT * FROM Rental WHERE rental_id = ?";
        try {
             PreparedStatement stmt = con.prepareStatement(query);

            stmt.setInt(1, rentalId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Rental(rs.getInt("rental_id"),
                                  rs.getInt("movie_id"),
                                  rs.getInt("customer_id"),
                                  rs.getDate("rental_start_date"),
                                  rs.getDate("rental_end_date"),
                                  rs.getDouble("total_charge"));
            }
        }
        catch (Exception ex) {
			ex.printStackTrace();
		}
        return null;
    }

    // Method to view all rentals
    public List<Rental> getAllRentals() throws SQLException {
        String query = "SELECT * FROM Rental";
        List<Rental> rentals = new ArrayList<>();
        try {
             PreparedStatement stmt = con.prepareStatement(query);

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                rentals.add(new Rental(rs.getInt("rental_id"),
                                       rs.getInt("movie_id"),
                                       rs.getInt("customer_id"),
                                       rs.getDate("rental_start_date"),
                                       rs.getDate("rental_end_date"),
                                       rs.getDouble("total_charge")));
            }
        }
        catch (Exception ex) {
			ex.printStackTrace();
		}
        return rentals;
    }
}